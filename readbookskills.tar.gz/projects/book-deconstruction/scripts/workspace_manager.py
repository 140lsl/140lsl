#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
工作区管理工具
用于创建书籍拆解工作目录并复制原文文件
"""

import argparse
import json
import os
import shutil
import sys
import re
from datetime import datetime


def sanitize_name(name):
    """清理书名，移除非法字符"""
    # 移除或替换非法文件名字符
    name = re.sub(r'[<>:"/\\|?*]', '', name)
    # 替换空格为下划线
    name = name.replace(' ', '_')
    # 移除首尾空格
    name = name.strip()
    # 限制长度
    if len(name) > 50:
        name = name[:50]
    return name if name else 'unnamed_book'


def create_workspace(book_name, source_file, output_dir="."):
    """
    创建工作区并复制原文文件

    Args:
        book_name: 书籍名称（用于生成目录名）
        source_file: 原文文件路径
        output_dir: 输出目录（默认当前目录）

    Returns:
        dict: 包含状态和路径信息
    """
    # 检查原文件是否存在
    if not os.path.exists(source_file):
        return {
            "status": "error",
            "message": f"原文件不存在: {source_file}"
        }

    # 清理书名
    clean_book_name = sanitize_name(book_name)

    # 创建工作区名称
    workspace_name = f"book-analysis-{clean_book_name}"
    workspace_path = os.path.join(output_dir, workspace_name)

    # 检查工作区是否已存在
    if os.path.exists(workspace_path):
        # 添加时间戳避免冲突
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        workspace_name = f"book-analysis-{clean_book_name}_{timestamp}"
        workspace_path = os.path.join(output_dir, workspace_name)

    try:
        # 创建工作区目录
        os.makedirs(workspace_path, exist_ok=True)

        # 创建子目录
        original_dir = os.path.join(workspace_path, "original")
        assets_dir = os.path.join(workspace_path, "assets")
        os.makedirs(original_dir, exist_ok=True)
        os.makedirs(assets_dir, exist_ok=True)

        # 复制原文文件
        source_filename = os.path.basename(source_file)
        original_copy_path = os.path.join(original_dir, source_filename)
        shutil.copy2(source_file, original_copy_path)

        # 定义报告路径
        report_path = os.path.join(workspace_path, "report.md")

        return {
            "status": "success",
            "workspace_path": workspace_path,
            "workspace_name": workspace_name,
            "original_copy_path": original_copy_path,
            "report_path": report_path,
            "assets_dir": assets_dir,
            "message": f"工作区创建成功: {workspace_path}"
        }

    except PermissionError:
        return {
            "status": "error",
            "message": f"权限不足，无法创建目录或复制文件: {workspace_path}"
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"创建工作区失败: {str(e)}"
        }


def main():
    parser = argparse.ArgumentParser(description="创建书籍拆解工作区并复制原文文件")
    parser.add_argument("--book-name", required=True, help="书籍名称（用于生成目录名）")
    parser.add_argument("--source-file", required=True, help="原文文件路径（支持任意格式）")
    parser.add_argument("--output-dir", default=".", help="输出目录（默认当前目录）")

    args = parser.parse_args()

    # 创建工作区
    result = create_workspace(args.book_name, args.source_file, args.output_dir)

    print(json.dumps(result, ensure_ascii=False, indent=2))

    # 返回退出码
    sys.exit(0 if result["status"] == "success" else 1)


if __name__ == "__main__":
    main()
