#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
书籍文本提取工具
支持格式：PDF、EPUB、TXT
"""

import argparse
import json
import os
import sys


def extract_from_pdf(file_path):
    """从PDF文件提取文本"""
    try:
        import PyPDF2
    except ImportError:
        return {"status": "error", "message": "PyPDF2未安装，请运行: pip install PyPDF2==3.0.1"}

    text = []
    try:
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            page_count = len(pdf_reader.pages)

            for page_num, page in enumerate(pdf_reader.pages, 1):
                try:
                    page_text = page.extract_text()
                    if page_text.strip():
                        text.append(page_text)
                except Exception as e:
                    # 跳过无法提取的页面
                    continue

        full_text = "\n\n".join(text)
        return {
            "status": "success",
            "text": full_text,
            "page_count": page_count,
            "format": "pdf"
        }
    except Exception as e:
        return {"status": "error", "message": f"PDF解析失败: {str(e)}"}


def extract_from_epub(file_path):
    """从EPUB文件提取文本"""
    try:
        from ebooklib import epub
    except ImportError:
        return {"status": "error", "message": "ebooklib未安装，请运行: pip install ebooklib==0.18"}

    try:
        book = epub.read_epub(file_path)
        text = []

        for item in book.get_items():
            if item.get_type() == 9:  # EPUB_ITEM_TYPE_DOCUMENT
                try:
                    content = item.get_content().decode('utf-8', errors='ignore')
                    # 简单清理HTML标签（保留基本文本）
                    import re
                    clean_text = re.sub(r'<[^>]+>', '\n', content)
                    clean_text = re.sub(r'\n+', '\n', clean_text)
                    clean_text = clean_text.strip()
                    if clean_text:
                        text.append(clean_text)
                except Exception as e:
                    # 跳过无法解析的章节
                    continue

        full_text = "\n\n".join(text)
        chapter_count = len(text)
        return {
            "status": "success",
            "text": full_text,
            "chapter_count": chapter_count,
            "format": "epub"
        }
    except Exception as e:
        return {"status": "error", "message": f"EPUB解析失败: {str(e)}"}


def extract_from_txt(file_path):
    """从TXT文件提取文本"""
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            text = file.read()

        # 估算页数（假设每页500字）
        page_count = len(text) // 500 + 1

        return {
            "status": "success",
            "text": text,
            "page_count": page_count,
            "format": "txt"
        }
    except UnicodeDecodeError:
        # 尝试其他编码
        try:
            with open(file_path, 'r', encoding='gbk') as file:
                text = file.read()
            page_count = len(text) // 500 + 1
            return {
                "status": "success",
                "text": text,
                "page_count": page_count,
                "format": "txt"
            }
        except Exception as e:
            return {"status": "error", "message": f"TXT解析失败（编码问题）: {str(e)}"}
    except Exception as e:
        return {"status": "error", "message": f"TXT解析失败: {str(e)}"}


def main():
    parser = argparse.ArgumentParser(description="从电子书文件提取纯文本")
    parser.add_argument("--file-path", required=True, help="电子书文件路径（支持PDF/EPUB/TXT）")

    args = parser.parse_args()

    # 检查文件是否存在
    if not os.path.exists(args.file_path):
        result = {"status": "error", "message": f"文件不存在: {args.file_path}"}
        print(json.dumps(result, ensure_ascii=False))
        sys.exit(1)

    # 获取文件扩展名
    file_ext = os.path.splitext(args.file_path)[1].lower()

    # 根据格式调用相应的提取函数
    if file_ext == '.pdf':
        result = extract_from_pdf(args.file_path)
    elif file_ext == '.epub':
        result = extract_from_epub(args.file_path)
    elif file_ext == '.txt':
        result = extract_from_txt(args.file_path)
    else:
        result = {
            "status": "error",
            "message": f"不支持的文件格式: {file_ext}，仅支持 PDF、EPUB、TXT"
        }

    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
